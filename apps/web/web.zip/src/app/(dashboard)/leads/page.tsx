'use client';

import { useEffect, useState, useCallback, useRef } from 'react';
import Link from 'next/link';
import { Users, Upload, Search, Phone, Copy, Check, MapPin, SlidersHorizontal, X, Mail, Trash2, Linkedin } from 'lucide-react';
import { apiClient } from '@/lib/api-client';
import { useCall } from '@/hooks/use-call';
import { useCallStore } from '@/store/call.store';
import { cn } from '@/lib/utils';

interface Lead {
  id: string;
  companyName: string;
  contactName: string | null;
  contactTitle: string | null;
  phoneNumber: string;
  country: string | null;
  location: string | null;
  email: string | null;
  industry: string | null;
  headcount: number | null;
  headcountGrowth6m: number | null;
  headcountGrowth12m: number | null;
  website: string | null;
  personalLinkedin: string | null;
  companyLinkedin: string | null;
  companyOverview: string | null;
  isOptOut: boolean;
  status: string;
  isWrongNumber: boolean;
  _count: { calls: number };
}

interface LeadsResponse {
  data: Lead[];
  meta: { total: number; page: number; limit: number; totalPages: number };
}

const statusColors: Record<string, string> = {
  NEW: 'badge-new',
  CONTACTED: 'badge-new',
  INTERESTED: 'badge-int',
  NOT_INTERESTED: 'badge-no',
  CALLBACK_SCHEDULED: 'badge-cb',
  WRONG_NUMBER: 'badge-no',
  OPT_OUT: 'badge-no',
};

type ColumnKey =
  | 'select' | 'contact' | 'company' | 'phone' | 'email' | 'location'
  | 'industry' | 'headcount' | 'growth6m' | 'growth12m'
  | 'website' | 'personalLinkedin' | 'companyLinkedin'
  | 'companyOverview' | 'status' | 'call';

interface ColumnDef {
  key: ColumnKey;
  label: string;
  defaultVisible: boolean;
  width?: string;
}

const ALL_COLUMNS: ColumnDef[] = [
  { key: 'select',          label: '',                   defaultVisible: true,  width: 'w-10' },
  { key: 'contact',         label: 'Contact',            defaultVisible: true,  width: 'min-w-[180px]' },
  { key: 'company',         label: 'Company',            defaultVisible: true,  width: 'min-w-[160px]' },
  { key: 'phone',           label: 'Phone',              defaultVisible: true,  width: 'min-w-[150px]' },
  { key: 'email',           label: 'Email',              defaultVisible: true,  width: 'min-w-[200px]' },
  { key: 'location',        label: 'Location',           defaultVisible: true,  width: 'min-w-[160px]' },
  { key: 'industry',        label: 'Industry',           defaultVisible: true,  width: 'min-w-[180px]' },
  { key: 'headcount',       label: 'Employees',          defaultVisible: false, width: 'min-w-[110px]' },
  { key: 'growth6m',        label: 'Growth 6m',          defaultVisible: false, width: 'min-w-[100px]' },
  { key: 'growth12m',       label: 'Growth 12m',         defaultVisible: false, width: 'min-w-[100px]' },
  { key: 'website',         label: 'Website',            defaultVisible: false, width: 'min-w-[180px]' },
  { key: 'personalLinkedin',label: 'LinkedIn',           defaultVisible: false, width: 'min-w-[60px]' },
  { key: 'companyLinkedin', label: 'Co. LinkedIn',       defaultVisible: false, width: 'min-w-[60px]' },
  { key: 'companyOverview', label: 'Overview',           defaultVisible: false, width: 'min-w-[240px]' },
  { key: 'status',          label: 'Status',             defaultVisible: true,  width: 'min-w-[130px]' },
  { key: 'call',            label: 'Call',               defaultVisible: true,  width: 'w-16' },
];

function formatLocation(location: string | null, country: string | null): string {
  const parts = [location, country]
    .filter(Boolean)
    .map(s => s!.trim())
    .filter(s => !/^[A-Z]{2}$/.test(s));
  return parts.join(', ');
}

const LIMIT = 25;

export default function LeadsPage() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [meta, setMeta] = useState<LeadsResponse['meta'] | null>(null);
  const [currentPage, setCurrentPage] = useState(1);
  const [search, setSearch] = useState('');
  const [loading, setLoading] = useState(true);
  const [copiedEmail, setCopiedEmail] = useState<string | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [jumpPage, setJumpPage] = useState('');
  const [showJump, setShowJump] = useState(false);
  const [visibleColumns, setVisibleColumns] = useState<Set<ColumnKey>>(
    new Set(ALL_COLUMNS.filter(c => c.defaultVisible).map(c => c.key))
  );
  const [showColumnPicker, setShowColumnPicker] = useState(false);
  const pickerRef = useRef<HTMLDivElement>(null);
  const jumpRef = useRef<HTMLDivElement>(null);
  const { initiateCall, isInitiating } = useCall();
  const { isOnCall } = useCallStore();

  const fetchLeads = useCallback(async (page = 1) => {
    setLoading(true);
    setSelected(new Set());
    try {
      const params: Record<string, any> = { page, limit: LIMIT };
      if (search) params.search = search;
      const response = await apiClient.get<LeadsResponse>('/leads', { params });
      setLeads(response.data.data);
      setMeta(response.data.meta);
      setCurrentPage(page);
    } catch (error) {
      console.error('Failed to fetch leads:', error);
    } finally {
      setLoading(false);
    }
  }, [search]);

  useEffect(() => { fetchLeads(1); }, []);

  // Close dropdowns on outside click
  useEffect(() => {
    const handler = (e: MouseEvent) => {
      if (pickerRef.current && !pickerRef.current.contains(e.target as Node)) setShowColumnPicker(false);
      if (jumpRef.current && !jumpRef.current.contains(e.target as Node)) setShowJump(false);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const handleSearch = (e: React.FormEvent) => { e.preventDefault(); fetchLeads(1); };
  const handleQuickCall = async (leadId: string) => { try { await initiateCall(leadId); } catch {} };
  const copyEmail = (email: string) => {
    navigator.clipboard.writeText(email);
    setCopiedEmail(email);
    setTimeout(() => setCopiedEmail(null), 2000);
  };

  // Selection
  const allIds = leads.map(l => l.id);
  const allSelected = allIds.length > 0 && allIds.every(id => selected.has(id));
  const someSelected = allIds.some(id => selected.has(id)) && !allSelected;
  const toggleSelectAll = () => {
    if (allSelected) {
      setSelected(prev => { const n = new Set(prev); allIds.forEach(id => n.delete(id)); return n; });
    } else {
      setSelected(prev => { const n = new Set(prev); allIds.forEach(id => n.add(id)); return n; });
    }
  };
  const toggleSelect = (id: string) => {
    setSelected(prev => { const n = new Set(prev); n.has(id) ? n.delete(id) : n.add(id); return n; });
  };

  const handleDeleteSelected = async () => {
    if (!confirm(`Delete ${selected.size} lead(s)? This cannot be undone.`)) return;
    try {
      await Promise.all([...selected].map(id => apiClient.delete(`/leads/${id}`)));
      fetchLeads(currentPage);
    } catch (err) {
      console.error('Delete failed', err);
    }
  };

  // Jump to page
  const handleJump = (e: React.FormEvent) => {
    e.preventDefault();
    const p = parseInt(jumpPage);
    if (p && meta && p >= 1 && p <= meta.totalPages) {
      fetchLeads(p);
      setShowJump(false);
      setJumpPage('');
    }
  };

  // Columns
  const toggleColumn = (key: ColumnKey) => {
    if (key === 'call' || key === 'select') return;
    setVisibleColumns(prev => { const n = new Set(prev); n.has(key) ? n.delete(key) : n.add(key); return n; });
  };
  const activeColumns = ALL_COLUMNS.filter(c => visibleColumns.has(c.key));
  const hiddenCount = ALL_COLUMNS.filter(c => c.key !== 'call' && c.key !== 'select' && !visibleColumns.has(c.key)).length;

  // Pagination info
  const pageStart = meta ? (meta.page - 1) * LIMIT + 1 : 0;
  const pageEnd = meta ? Math.min(meta.page * LIMIT, meta.total) : 0;

  const renderCell = (lead: Lead, col: ColumnKey) => {
    const canCall = !lead.isWrongNumber && !isOnCall && !isInitiating;
    switch (col) {
      case 'select':
        return (
          <td key={col} className="w-10 px-3 py-3">
            <input
              type="checkbox"
              checked={selected.has(lead.id)}
              onChange={() => toggleSelect(lead.id)}
              className="h-3.5 w-3.5 rounded accent-blue-500"
              onClick={e => e.stopPropagation()}
            />
          </td>
        );
      case 'contact':
        return (
          <td key={col} className="px-5 py-3 min-w-[180px]">
            <Link href={`/leads/${lead.id}`} className="text-sm font-medium hover:text-blue-500" style={{ color: 'var(--foreground)' }}>
              {lead.contactName || '—'}
            </Link>
            {lead.contactTitle && (
              <p className="text-xs mt-0.5 truncate max-w-[180px]" style={{ color: 'var(--muted)' }}>{lead.contactTitle}</p>
            )}
          </td>
        );
      case 'company':
        return (
          <td key={col} className="px-5 py-3 min-w-[160px]">
            <Link href={`/leads/${lead.id}`} className="text-sm hover:text-blue-500" style={{ color: 'var(--foreground)' }}>
              {lead.companyName}
            </Link>
          </td>
        );
      case 'phone':
        return (
          <td key={col} className="px-5 py-3 min-w-[150px]">
            <p className="text-sm" style={{ color: 'var(--foreground)' }}>{lead.phoneNumber}</p>
          </td>
        );
      case 'email':
        return (
          <td key={col} className="px-5 py-3 min-w-[200px]">
            {lead.email ? (
              <div className="flex items-center gap-1">
                <p className="text-xs truncate max-w-[170px]" style={{ color: 'var(--muted)' }}>{lead.email}</p>
                <button onClick={() => copyEmail(lead.email!)} className="flex-shrink-0 rounded p-0.5" style={{ color: 'var(--muted)' }} title="Copy email">
                  {copiedEmail === lead.email ? <Check className="h-3 w-3 text-green-500" /> : <Copy className="h-3 w-3" />}
                </button>
              </div>
            ) : <span className="text-sm" style={{ color: 'var(--muted)' }}>—</span>}
          </td>
        );
      case 'location': {
        const loc = formatLocation(lead.location, lead.country);
        return (
          <td key={col} className="px-5 py-3 min-w-[160px]">
            {loc ? (
              <div className="flex items-center gap-1 text-sm" style={{ color: 'var(--muted)' }}>
                <MapPin className="h-3 w-3 flex-shrink-0" />
                <span className="truncate max-w-[140px]">{loc}</span>
              </div>
            ) : <span className="text-sm" style={{ color: 'var(--muted)' }}>—</span>}
          </td>
        );
      }
      case 'industry':
        return (
          <td key={col} className="px-5 py-3 min-w-[180px]">
            {lead.industry ? (
              <span className="inline-flex rounded-md px-2 py-0.5 text-xs font-medium" style={{ backgroundColor: 'var(--tag-bg)', color: 'var(--tag-text)' }}>
                {lead.industry}
              </span>
            ) : <span className="text-sm" style={{ color: 'var(--muted)' }}>—</span>}
          </td>
        );
      case 'headcount':
        return (
          <td key={col} className="px-5 py-3 min-w-[110px]">
            <span className="text-sm" style={{ color: 'var(--foreground)' }}>{lead.headcount ? lead.headcount.toLocaleString() : '—'}</span>
          </td>
        );
      case 'growth6m':
        return (
          <td key={col} className="px-5 py-3 min-w-[100px]">
            {lead.headcountGrowth6m != null
              ? <span className={cn('text-sm font-medium', lead.headcountGrowth6m >= 0 ? 'text-green-500' : 'text-red-400')}>{lead.headcountGrowth6m > 0 ? '+' : ''}{lead.headcountGrowth6m}%</span>
              : <span className="text-sm" style={{ color: 'var(--muted)' }}>—</span>}
          </td>
        );
      case 'growth12m':
        return (
          <td key={col} className="px-5 py-3 min-w-[100px]">
            {lead.headcountGrowth12m != null
              ? <span className={cn('text-sm font-medium', lead.headcountGrowth12m >= 0 ? 'text-green-500' : 'text-red-400')}>{lead.headcountGrowth12m > 0 ? '+' : ''}{lead.headcountGrowth12m}%</span>
              : <span className="text-sm" style={{ color: 'var(--muted)' }}>—</span>}
          </td>
        );
      case 'website':
        return (
          <td key={col} className="px-5 py-3 min-w-[180px]">
            {lead.website
              ? <a href={lead.website} target="_blank" rel="noopener noreferrer" className="text-xs text-blue-500 hover:underline truncate block max-w-[160px]">{lead.website.replace(/^https?:\/\//, '')}</a>
              : <span className="text-sm" style={{ color: 'var(--muted)' }}>—</span>}
          </td>
        );
      case 'personalLinkedin':
        return (
          <td key={col} className="px-5 py-3 min-w-[60px]">
            {lead.personalLinkedin
              ? <a href={lead.personalLinkedin} target="_blank" rel="noopener noreferrer" title="Personal LinkedIn" className="inline-flex items-center justify-center h-7 w-7 rounded-md transition-colors hover:bg-blue-600/10">
                  <Linkedin className="h-4 w-4 text-[#0A66C2]" />
                </a>
              : <span className="text-sm" style={{ color: 'var(--muted)' }}>—</span>}
          </td>
        );
      case 'companyLinkedin':
        return (
          <td key={col} className="px-5 py-3 min-w-[60px]">
            {lead.companyLinkedin
              ? <a href={lead.companyLinkedin} target="_blank" rel="noopener noreferrer" title="Company LinkedIn" className="inline-flex items-center justify-center h-7 w-7 rounded-md transition-colors hover:bg-blue-600/10">
                  <Linkedin className="h-4 w-4 text-[#0A66C2]" />
                </a>
              : <span className="text-sm" style={{ color: 'var(--muted)' }}>—</span>}
          </td>
        );
      case 'companyOverview':
        return (
          <td key={col} className="px-5 py-3 min-w-[240px]">
            {lead.companyOverview
              ? <p className="text-xs line-clamp-2 max-w-[220px]" style={{ color: 'var(--muted)' }}>{lead.companyOverview}</p>
              : <span className="text-sm" style={{ color: 'var(--muted)' }}>—</span>}
          </td>
        );
      case 'status':
        return (
          <td key={col} className="px-5 py-3 min-w-[130px]">
            <span className={cn('inline-flex rounded-full px-2 py-0.5 text-xs font-medium', statusColors[lead.status] || statusColors.NEW)}>
              {lead.status.replace(/_/g, ' ')}
            </span>
          </td>
        );
      case 'call':
        return (
          <td key={col} className="px-5 py-3 text-center w-16">
            <button
              onClick={() => handleQuickCall(lead.id)}
              disabled={!canCall}
              className={cn('inline-flex h-8 w-8 items-center justify-center rounded-full transition-all', canCall ? 'bg-green-50 text-green-600 hover:bg-green-100 hover:scale-110' : 'cursor-not-allowed opacity-40')}
              style={!canCall ? { backgroundColor: 'var(--hover-bg)', color: 'var(--muted)' } : {}}
              title={lead.isWrongNumber ? 'Wrong number' : isOnCall ? 'Already on a call' : `Call ${lead.contactName || lead.companyName}`}
            >
              <Phone className="h-4 w-4" />
            </button>
          </td>
        );
      default:
        return <td key={col} />;
    }
  };

  const PaginationBar = () => (
    <div className="flex items-center gap-2">
      {/* Prev */}
      <button
        onClick={() => fetchLeads(currentPage - 1)}
        disabled={currentPage <= 1 || loading}
        className="rounded-lg border px-3 py-1.5 text-sm disabled:opacity-40 transition-colors"
        style={{ borderColor: 'var(--card-border)', color: 'var(--foreground)', backgroundColor: 'var(--card-bg)' }}
        onMouseEnter={e => ((e.currentTarget as HTMLElement).style.backgroundColor = 'var(--hover-bg)')}
        onMouseLeave={e => ((e.currentTarget as HTMLElement).style.backgroundColor = 'var(--card-bg)')}
      >
        ‹
      </button>

      {/* Jump to page */}
      <div className="relative" ref={jumpRef}>
        <button
          onClick={() => setShowJump(p => !p)}
          className="flex items-center gap-1 rounded-lg border px-3 py-1.5 text-sm font-medium transition-colors"
          style={{ borderColor: 'var(--card-border)', color: 'var(--foreground)', backgroundColor: showJump ? 'var(--hover-bg)' : 'var(--card-bg)', minWidth: 36, justifyContent: 'center' }}
        >
          {currentPage}
          <span className="text-xs" style={{ color: 'var(--muted)' }}>▾</span>
        </button>
        {showJump && meta && (
          <div
            className="absolute bottom-10 left-0 z-50 rounded-xl shadow-xl p-2 overflow-y-auto"
            style={{ backgroundColor: 'var(--card-bg)', border: '1px solid var(--card-border)', maxHeight: 220, width: 80 }}
          >
            {Array.from({ length: meta.totalPages }, (_, i) => i + 1).map(p => (
              <button
                key={p}
                onClick={() => { fetchLeads(p); setShowJump(false); }}
                className="w-full rounded-lg px-2 py-1.5 text-sm text-left transition-colors"
                style={{
                  backgroundColor: p === currentPage ? 'var(--accent)' : 'transparent',
                  color: p === currentPage ? '#fff' : 'var(--foreground)',
                }}
                onMouseEnter={e => { if (p !== currentPage) (e.currentTarget as HTMLElement).style.backgroundColor = 'var(--hover-bg)'; }}
                onMouseLeave={e => { if (p !== currentPage) (e.currentTarget as HTMLElement).style.backgroundColor = 'transparent'; }}
              >
                {p}
              </button>
            ))}
          </div>
        )}
      </div>

      <span className="text-sm" style={{ color: 'var(--muted)' }}>of {meta?.totalPages ?? '—'}</span>

      {/* Next */}
      <button
        onClick={() => fetchLeads(currentPage + 1)}
        disabled={!meta || currentPage >= meta.totalPages || loading}
        className="rounded-lg border px-3 py-1.5 text-sm disabled:opacity-40 transition-colors"
        style={{ borderColor: 'var(--card-border)', color: 'var(--foreground)', backgroundColor: 'var(--card-bg)' }}
        onMouseEnter={e => ((e.currentTarget as HTMLElement).style.backgroundColor = 'var(--hover-bg)')}
        onMouseLeave={e => ((e.currentTarget as HTMLElement).style.backgroundColor = 'var(--card-bg)')}
      >
        ›
      </button>

      {/* Range info */}
      {meta && (
        <span className="text-sm ml-1" style={{ color: 'var(--muted)' }}>
          {pageStart}–{pageEnd} of {meta.total}
        </span>
      )}
    </div>
  );

  return (
    <div>
      {/* Header */}
      <div className="mb-6 flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold" style={{ color: 'var(--foreground)' }}>Leads</h1>
          <p className="mt-1 text-sm" style={{ color: 'var(--muted)' }}>
            {meta ? `${meta.total} leads total` : 'Loading...'}
          </p>
        </div>
        <Link
          href="/leads/import"
          className="flex items-center gap-2 rounded-lg bg-blue-600 px-4 py-2 text-sm font-medium text-white transition-colors hover:bg-blue-700"
        >
          <Upload className="h-4 w-4" />
          Import CSV
        </Link>
      </div>

      {/* Search + Column picker */}
      <div className="mb-4 flex items-center gap-3">
        <form onSubmit={handleSearch} className="flex-1">
          <div className="relative">
            <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2" style={{ color: 'var(--muted)' }} />
            <input
              type="text"
              value={search}
              onChange={e => setSearch(e.target.value)}
              placeholder="Search by company, contact, phone, or industry..."
              className="w-full rounded-lg border py-2 pl-10 pr-4 text-sm focus:outline-none focus:ring-1 focus:ring-blue-500"
              style={{ backgroundColor: 'var(--input-bg)', borderColor: 'var(--input-border)', color: 'var(--foreground)' }}
            />
          </div>
        </form>
        <div className="relative" ref={pickerRef}>
          <button
            onClick={() => setShowColumnPicker(p => !p)}
            className="flex items-center gap-2 rounded-lg border px-3 py-2 text-sm transition-colors"
            style={{ backgroundColor: showColumnPicker ? 'var(--hover-bg)' : 'var(--card-bg)', borderColor: 'var(--card-border)', color: 'var(--foreground)' }}
          >
            <SlidersHorizontal className="h-4 w-4" />
            Columns
            {hiddenCount > 0 && <span className="rounded-full bg-blue-600 px-1.5 py-0.5 text-xs text-white leading-none">+{hiddenCount}</span>}
          </button>
          {showColumnPicker && (
            <div className="absolute right-0 top-10 z-50 w-56 rounded-xl p-3 shadow-xl" style={{ backgroundColor: 'var(--card-bg)', border: '1px solid var(--card-border)' }}>
              <div className="mb-2 flex items-center justify-between">
                <span className="text-xs font-semibold uppercase tracking-wider" style={{ color: 'var(--muted)' }}>Toggle Columns</span>
                <button onClick={() => setShowColumnPicker(false)} style={{ color: 'var(--muted)' }}><X className="h-3.5 w-3.5" /></button>
              </div>
              <div className="space-y-0.5">
                {ALL_COLUMNS.filter(c => c.key !== 'call' && c.key !== 'select').map(col => (
                  <label key={col.key} className="flex cursor-pointer items-center gap-2 rounded-lg px-2 py-1.5 text-sm transition-colors" style={{ color: 'var(--foreground)' }}
                    onMouseEnter={e => (e.currentTarget.style.backgroundColor = 'var(--hover-bg)')}
                    onMouseLeave={e => (e.currentTarget.style.backgroundColor = 'transparent')}
                  >
                    <input type="checkbox" checked={visibleColumns.has(col.key)} onChange={() => toggleColumn(col.key)} className="h-3.5 w-3.5 rounded accent-blue-500" />
                    {col.label}
                  </label>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Top pagination bar */}
      <div className="mb-3 flex items-center justify-between">
        {/* Selection toolbar — appears when rows are selected */}
        {selected.size > 0 ? (
          <div className="flex items-center gap-3 rounded-lg px-3 py-1.5" style={{ backgroundColor: 'var(--card-bg)', border: '1px solid var(--card-border)' }}>
            <button onClick={() => setSelected(new Set())} className="flex items-center gap-1.5 text-sm font-medium" style={{ color: 'var(--foreground)' }}>
              <X className="h-3.5 w-3.5" />
              Clear {selected.size} selected
            </button>
            <div className="h-4 w-px" style={{ backgroundColor: 'var(--card-border)' }} />
            <button className="flex items-center gap-1.5 rounded-md px-2 py-1 text-sm transition-colors hover:bg-blue-600/10 text-blue-500" title="Email selected">
              <Mail className="h-4 w-4" />
            </button>
            <button onClick={handleDeleteSelected} className="flex items-center gap-1.5 rounded-md px-2 py-1 text-sm transition-colors hover:bg-red-500/10 text-red-500" title="Delete selected">
              <Trash2 className="h-4 w-4" />
            </button>
          </div>
        ) : (
          <div />
        )}
        <PaginationBar />
      </div>

      {/* Table */}
      <div className="overflow-x-auto rounded-xl" style={{ backgroundColor: '#2B2A2C', border: 'none' }}>
        <table className="w-full" style={{ borderCollapse: 'collapse' }}>
          <thead>
            <tr style={{ backgroundColor: '#2B2A2C' }}>
              {activeColumns.map((col) => (
                col.key === 'select' ? (
                  <th key="select" className="w-10 px-3 py-3">
                    <input
                      type="checkbox"
                      checked={allSelected}
                      ref={el => { if (el) el.indeterminate = someSelected; }}
                      onChange={toggleSelectAll}
                      className="h-3.5 w-3.5 rounded accent-blue-500"
                    />
                  </th>
                ) : (
                  <th
                    key={col.key}
                    className={cn('px-5 py-3 text-left text-xs font-medium uppercase tracking-wider whitespace-nowrap', col.width, col.key === 'call' && 'text-center')}
                    style={{ color: 'var(--muted)' }}
                  >
                    {col.label}
                  </th>
                )
              ))}
            </tr>
            <tr>
              <td colSpan={activeColumns.length} style={{ padding: 0, borderTop: '1px solid var(--table-divider)' }} />
            </tr>
          </thead>
          <tbody>
            {loading ? (
              <tr><td colSpan={activeColumns.length} className="px-6 py-12 text-center text-sm" style={{ color: 'var(--muted)' }}>Loading leads...</td></tr>
            ) : leads.length === 0 ? (
              <tr>
                <td colSpan={activeColumns.length} className="px-6 py-12 text-center">
                  <Users className="mx-auto h-8 w-8" style={{ color: 'var(--muted)' }} />
                  <p className="mt-2 text-sm" style={{ color: 'var(--muted)' }}>No leads found</p>
                  <Link href="/leads/import" className="mt-2 inline-block text-sm text-blue-600 hover:text-blue-500">Import your first CSV</Link>
                </td>
              </tr>
            ) : (
              leads.map(lead => (
                <tr
                  key={lead.id}
                  style={{ backgroundColor: selected.has(lead.id) ? 'var(--hover-bg)' : 'transparent' }}
                  onMouseEnter={e => { if (!selected.has(lead.id)) (e.currentTarget as HTMLElement).style.backgroundColor = 'var(--hover-bg)'; }}
                  onMouseLeave={e => { if (!selected.has(lead.id)) (e.currentTarget as HTMLElement).style.backgroundColor = 'transparent'; }}
                >
                  {activeColumns.map(col => renderCell(lead, col.key))}
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Bottom pagination bar */}
      <div className="mt-4 flex justify-end">
        <PaginationBar />
      </div>
    </div>
  );
}